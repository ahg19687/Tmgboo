from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
def inline_back_buttons(prev_label="◀️ بازگشت", main_label="🏠 منوی اصلی"):
    kb = [[InlineKeyboardButton(prev_label, callback_data="back_prev"), InlineKeyboardButton(main_label, callback_data="back_main")]]
    return InlineKeyboardMarkup(kb)
def reply_start_keyboard():
    kb = [[KeyboardButton("/start")]]
    return ReplyKeyboardMarkup(kb, resize_keyboard=True, one_time_keyboard=False)
