import os
from utils.database import load_json
NOTIF_PATH = os.path.join("data", "notifications.json")
ADMINS_PATH = os.path.join("data", "admins.json")
def load_notifications():
    return load_json(NOTIF_PATH, {"user_new": True, "subscription_expired": True, "group_added": True, "group_deleted": True})
def can_notify(kind: str):
    notif = load_notifications()
    return notif.get(kind, False)
def list_admins():
    data = load_json(ADMINS_PATH, {})
    return [int(k) for k in data.keys()]
