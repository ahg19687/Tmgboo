MESSAGES = {
    "fa": {
        "start_locked": "🔒 حساب شما قفل است. برای فعال‌سازی از دکمهٔ پشتیبانی استفاده کنید.",
        "start_unlocked": "✅ خوش آمدید! از منو استفاده کنید.",
        "support_prompt": "برای پشتیبانی با ادمین‌ها در ارتباط باشید:\n{admins}",
        "ask_code": "🔐 لطفاً کد قفل‌گشایی را وارد کنید یا از /unlock <کد> استفاده کنید.",
        "code_ok": "✅ کد معتبر است. اشتراک شما تا {until} فعال شد.",
        "code_invalid": "❌ کد نامعتبر یا منقضی یا برای شما نیست.",
        "lang_changed": "زبان به {lang} تغییر کرد.",
        "reminder_message": "⚠️ اشتراک شما تمام شده. لطفاً برای تمدید با پشتیبانی تماس بگیرید."
    },
    "en": {
        "start_locked": "🔒 Your account is locked. Use Support to get an unlock code.",
        "start_unlocked": "✅ Welcome! Use the menu.",
        "support_prompt": "Contact admins for support:\n{admins}",
        "ask_code": "🔐 Enter unlock code or use /unlock <code>.",
        "code_ok": "✅ Code valid. Your subscription is active until {until}.",
        "code_invalid": "❌ Code invalid, expired, or not for you.",
        "lang_changed": "Language changed to {lang}.",
        "reminder_message": "⚠️ Your subscription has expired. Please contact support to renew."
    }
}

LANG_LABEL = {"fa": "فارسی", "en": "English"}
