import zipfile, os

def create_backup(output_path='backups/backup.zip'):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with zipfile.ZipFile(output_path, 'w') as z:
        for f in ['data/users.json','data/admins.json','data/groups.json','data/codes.json','data/support.txt','data/notifications.json']:
            if os.path.exists(f):
                z.write(f)
    return output_path
