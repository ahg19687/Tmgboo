from datetime import datetime, timezone
import pytz
TEHRAN_TZ = pytz.timezone("Asia/Tehran")
def dt_to_readable(dt):
    try:
        return dt.astimezone(TEHRAN_TZ).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "—"
