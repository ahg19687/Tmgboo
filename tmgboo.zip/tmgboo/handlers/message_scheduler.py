async def send_message_to_all(bot):
    return
