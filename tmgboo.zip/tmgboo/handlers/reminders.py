async def process_expirations(bot):
    return
